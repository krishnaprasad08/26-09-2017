import React, { Component } from 'react';
import './tab1.css';
class Tab1 extends Component
{
    render()
    {
        return(

            <span className="Text1">
                <input type="text"  className="bc" disabled="disabled"/>
                </span>

        );

    }
}
export default Tab1;