import React, { Component } from 'react';
import './tab.css';
class Tab extends Component {
    constructor(props){
        super(props);
        this.state = {
            value : this.props.value ? this.props.value : ''
        }
        this.Change = this.Change.bind(this);
    }
    Change(e){
        this.setState({
            value : e.target.value
        },()=>{
            console.log("onchange")
            this.props.updateSwipehours(this.props.day,this.state.value);
        })
        
    }
    render() {
       
        return (

            <span className="Text1">
                <input type="text" value={this.state.value} onChange={this.Change} className="b" />
            </span>

        );

    }
}
export default Tab;